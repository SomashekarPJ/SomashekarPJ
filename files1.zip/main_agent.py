"""
DecisionOS v2 — Main Entry Point
===================================
Run this file to ask a business question to the multi-agent system.

Usage:
    python main_agent.py

Make sure your .env file contains:
    ANTHROPIC_API_KEY=your-actual-key-here

Example questions to try:
    - "Should we launch a retention campaign for month-to-month customers?"
    - "Which customer segment is at highest churn risk this quarter?"
    - "Should we increase promotions in Type A stores next month?"
    - "Is our churn rate improving or getting worse?"
"""

import os
import sys
from pathlib import Path
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent))

from orchestrator import run_orchestrator


def main():
    # ── Get API key ──────────────────────────────────────────────────────
    api_key = os.getenv("ANTHROPIC_API_KEY")

    if not api_key:
        print("\n ERROR: ANTHROPIC_API_KEY not found.")
        print(" Create a .env file in your project folder with:")
        print(" ANTHROPIC_API_KEY=your-actual-key-here\n")
        sys.exit(1)

    # ── Business questions to run ────────────────────────────────────────
    # You can change this to any business question
    questions = [
        "Should we launch a targeted retention campaign for month-to-month customers this quarter?",
    ]

    for question in questions:
        result = run_orchestrator(question, api_key)

        # Save result to JSON file
        import json
        output_path = Path(__file__).parent / "agent_outputs"
        output_path.mkdir(exist_ok=True)

        filename = output_path / f"decision_{len(list(output_path.glob('*.json')))+1:03d}.json"
        with open(filename, "w") as f:
            json.dump(result, f, indent=2)

        print(f"  Result saved → {filename.name}\n")


if __name__ == "__main__":
    main()
