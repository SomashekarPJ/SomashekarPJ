"""
DecisionOS v2 — Data Agent
===========================
Role     : Retrieve and structure business data relevant to the question.
Input    : A business question (string)
Output   : Structured JSON with metrics, data quality, and warnings
Fallback : Returns error JSON if API fails — orchestrator handles gracefully
"""

import os
import json
from anthropic import Anthropic

# ── System Prompt ─────────────────────────────────────────────────────────────
DATA_AGENT_PROMPT = """
You are the DATA AGENT in DecisionOS v2, a Business Decision Intelligence system.

YOUR ROLE:
- Retrieve and structure business data relevant to the user's question
- Provide realistic, plausible mock business metrics based on the question context
- Flag any data quality issues or missing information
- You do NOT make business recommendations — that is not your role

DECISIONOS v2 CONTEXT:
- The system analyses customer churn (IBM Telco dataset) and retail sales (Rossmann dataset)
- Churn model metrics: Accuracy 78.82%, F1 58.15%, AUC-ROC 84.08%
- Sales model metrics: RMSE €1,939, R² 0.5913
- Top churn predictors: Contract type, Monthly Charges, Tenure
- Top sales predictors: Store ID, Competition Distance, Promo

OUTPUT FORMAT — respond ONLY with this exact JSON structure, no extra text:
{
  "status": "success" or "error",
  "data_quality": "high", "medium", or "low",
  "data_age_days": <integer — how fresh the data is>,
  "metrics": {
    "primary_metric": <most relevant number for the question>,
    "secondary_metric": <second most relevant number>,
    "growth_rate": <percentage as float>,
    "risk_score": <float between 0 and 10>,
    "sample_size": <integer — number of records analysed>,
    "confidence_interval": "<lower>% to <upper>%"
  },
  "segments": {
    "highest_risk": "<segment name>",
    "lowest_risk": "<segment name>",
    "most_valuable": "<segment name>"
  },
  "warnings": ["<any data quality issue>"],
  "data_sources": ["<source 1>", "<source 2>"]
}

CONSTRAINTS:
- Never invent wildly unrealistic numbers
- Never make strategy recommendations
- If data would be missing in reality, set the field to null and add a warning
- Always return valid JSON — no markdown, no extra explanation
"""


def run_data_agent(question: str, client: Anthropic) -> dict:
    """
    Run the Data Agent on a business question.
    Returns a dict with status, data, and metadata.
    """
    print("  [Data Agent] Fetching business data...")

    try:
        response = client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=1000,
            messages=[
                {
                    "role": "user",
                    "content": f"Business question: {question}\n\nProvide the relevant business data for this question."
                }
            ],
            system=DATA_AGENT_PROMPT
        )

        raw = response.content[0].text.strip()

        # Clean any accidental markdown fences
        raw = raw.replace("```json", "").replace("```", "").strip()

        data = json.loads(raw)

        print(f"  [Data Agent] Done — quality: {data.get('data_quality', 'unknown')}, "
              f"warnings: {len(data.get('warnings', []))}")

        return {"status": "success", "data": data, "agent": "data_agent"}

    except json.JSONDecodeError as e:
        print(f"  [Data Agent] JSON parse error: {e}")
        return {
            "status": "error",
            "error": f"JSON parse failed: {str(e)}",
            "agent": "data_agent",
            "data": None
        }
    except Exception as e:
        print(f"  [Data Agent] Error: {e}")
        return {
            "status": "error",
            "error": str(e),
            "agent": "data_agent",
            "data": None
        }
