"""
DecisionOS v2 — Recommendation Agent
=======================================
Role     : Synthesise all inputs and produce a structured business recommendation
Input    : Question + data + analysis + risk assessment
Output   : Final decision with confidence score and reasoning chain
Fallback : Returns error JSON if API fails
"""

import json
from anthropic import Anthropic

# ── System Prompt ─────────────────────────────────────────────────────────────
RECOMMENDATION_AGENT_PROMPT = """
You are the RECOMMENDATION AGENT in DecisionOS v2, a Business Decision Intelligence system.

YOUR ROLE:
- Synthesise data, analysis, and risk findings into a clear business recommendation
- Produce a confident, justified, actionable decision
- Assign a confidence score based on data quality and consensus
- Provide clear next steps for the business to act on
- This is the DECISION layer — you give the final answer

DECISIONOS v2 CONTEXT:
- You have access to churn predictions (AUC-ROC 84%) and sales forecasts (R² 0.59)
- Month-to-month customers churn at 42.7% — contract conversion is the #1 lever
- Promotions drive 38.8% sales uplift — key tool for revenue growth
- Always weigh cost of action vs cost of inaction

CONFIDENCE SCORING RULES:
- Start at 1.0
- Subtract 0.15 for each missing critical data field
- Subtract 0.10 if data is older than 30 days
- Subtract 0.20 if analysis shows high_uncertainty = true
- Subtract 0.10 if risk level is high
- Minimum confidence: 0.10

OUTPUT FORMAT — respond ONLY with this exact JSON structure, no extra text:
{
  "status": "success" or "error",
  "decision": "proceed", "delay", or "decline",
  "confidence": <float 0.0 to 1.0>,
  "primary_reason": "<one clear sentence justifying the decision>",
  "key_findings": [
    "<most important finding supporting the decision>",
    "<second finding>",
    "<third finding>"
  ],
  "risks_acknowledged": ["<key risk 1>", "<key risk 2>"],
  "next_steps": [
    "<specific actionable step 1>",
    "<specific actionable step 2>",
    "<specific actionable step 3>"
  ],
  "data_gaps": ["<missing data that would improve confidence, or empty list>"],
  "expected_impact": "<quantified business outcome if recommendation is followed>"
}

CONSTRAINTS:
- Always give a clear decision — never be vague
- Quote actual numbers in primary_reason
- Next steps must be specific and actionable, not generic
- Always return valid JSON — no markdown, no extra text
"""


def run_recommendation_agent(
    question: str,
    data: dict,
    analysis: dict,
    risk: dict,
    client: Anthropic
) -> dict:
    """
    Run the Recommendation Agent to produce the final business decision.
    Returns recommendation dict.
    """
    print("  [Recommendation Agent] Generating recommendation...")

    try:
        user_message = f"""
Business question: {question}

DATA SUMMARY:
- Quality: {data.get('data_quality', 'unknown')}
- Age: {data.get('data_age_days', 'unknown')} days
- Primary metric: {data.get('metrics', {}).get('primary_metric', 'unknown')}
- Growth rate: {data.get('metrics', {}).get('growth_rate', 'unknown')}%
- Risk score from data: {data.get('metrics', {}).get('risk_score', 'unknown')}
- Warnings: {data.get('warnings', [])}

ANALYSIS FINDINGS:
- Trend: {analysis.get('trend', 'unknown')}
- Urgency: {analysis.get('urgency', 'unknown')}
- Key findings: {analysis.get('key_findings', [])}
- Business impact: {analysis.get('business_impact', 'unknown')}
- High uncertainty: {analysis.get('high_uncertainty', False)}

RISK ASSESSMENT:
- Overall risk level: {risk.get('overall_risk_level', 'unknown')}
- Risk score: {risk.get('risk_score', 'unknown')}
- Top risks: {[r.get('risk', '') for r in risk.get('risks', [])[:2]]}
- Worst case: {risk.get('worst_case_scenario', 'unknown')}

Based on all the above, give your final business recommendation.
"""

        response = client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=1000,
            messages=[{"role": "user", "content": user_message}],
            system=RECOMMENDATION_AGENT_PROMPT
        )

        raw = response.content[0].text.strip()
        raw = raw.replace("```json", "").replace("```", "").strip()

        result = json.loads(raw)

        print(f"  [Recommendation Agent] Done — decision: {result.get('decision', 'unknown').upper()}, "
              f"confidence: {result.get('confidence', 0)*100:.0f}%")

        return {"status": "success", "recommendation": result, "agent": "recommendation_agent"}

    except json.JSONDecodeError as e:
        print(f"  [Recommendation Agent] JSON parse error: {e}")
        return {
            "status": "error",
            "error": f"JSON parse failed: {str(e)}",
            "agent": "recommendation_agent",
            "recommendation": None
        }
    except Exception as e:
        print(f"  [Recommendation Agent] Error: {e}")
        return {
            "status": "error",
            "error": str(e),
            "agent": "recommendation_agent",
            "recommendation": None
        }
