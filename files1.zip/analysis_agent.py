"""
DecisionOS v2 — Analysis Agent
================================
Role     : Analyse structured data and identify key business insights
Input    : Business question + structured data from Data Agent
Output   : Structured JSON with findings, trends, and anomalies
Fallback : Returns error JSON if API fails
"""

import json
from anthropic import Anthropic

# ── System Prompt ─────────────────────────────────────────────────────────────
ANALYSIS_AGENT_PROMPT = """
You are the ANALYSIS AGENT in DecisionOS v2, a Business Decision Intelligence system.

YOUR ROLE:
- Analyse the structured business data provided
- Identify key trends, patterns, and anomalies
- Calculate business implications of the data
- Highlight what the numbers mean for the business
- You do NOT make final recommendations — that is the Recommendation Agent's job

DECISIONOS v2 CONTEXT:
- Churn model: 78.82% accuracy, AUC-ROC 84.08%, top predictor is Contract type
- Sales model: R² 0.5913, RMSE €1,939, top predictor is Store ID
- Month-to-month customers churn at 42.7% vs 2.8% for 2-year contracts
- Promotions drive 38.8% average sales uplift

OUTPUT FORMAT — respond ONLY with this exact JSON structure, no extra text:
{
  "status": "success" or "error",
  "key_findings": [
    "<specific, data-backed finding 1>",
    "<specific, data-backed finding 2>",
    "<specific, data-backed finding 3>"
  ],
  "trend": "improving", "declining", or "stable",
  "anomalies": ["<anything unusual in the data>"],
  "business_impact": "<one sentence on what this means financially>",
  "urgency": "high", "medium", or "low",
  "high_uncertainty": <true or false>,
  "uncertainty_reason": "<why uncertain, or null if not>",
  "supporting_metrics": {
    "metric_name": "value and interpretation"
  }
}

CONSTRAINTS:
- Base ALL findings strictly on the data provided — no invention
- Be specific — quote actual numbers from the data
- Flag high_uncertainty as true if data quality is low or data is old
- Never recommend actions — only analyse what the data shows
- Always return valid JSON — no markdown, no extra text
"""


def run_analysis_agent(question: str, data: dict, client: Anthropic) -> dict:
    """
    Run the Analysis Agent on structured data.
    Returns findings dict.
    """
    print("  [Analysis Agent] Analysing data...")

    try:
        user_message = f"""
Business question: {question}

Data to analyse:
- Data quality: {data.get('data_quality', 'unknown')}
- Data age: {data.get('data_age_days', 'unknown')} days
- Metrics: {json.dumps(data.get('metrics', {}), indent=2)}
- Segments: {json.dumps(data.get('segments', {}), indent=2)}
- Warnings: {data.get('warnings', [])}
- Sources: {data.get('data_sources', [])}

Analyse this data and return your findings.
"""

        response = client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=1000,
            messages=[{"role": "user", "content": user_message}],
            system=ANALYSIS_AGENT_PROMPT
        )

        raw = response.content[0].text.strip()
        raw = raw.replace("```json", "").replace("```", "").strip()

        result = json.loads(raw)

        print(f"  [Analysis Agent] Done — trend: {result.get('trend', 'unknown')}, "
              f"urgency: {result.get('urgency', 'unknown')}")

        return {"status": "success", "analysis": result, "agent": "analysis_agent"}

    except json.JSONDecodeError as e:
        print(f"  [Analysis Agent] JSON parse error: {e}")
        return {
            "status": "error",
            "error": f"JSON parse failed: {str(e)}",
            "agent": "analysis_agent",
            "analysis": None
        }
    except Exception as e:
        print(f"  [Analysis Agent] Error: {e}")
        return {
            "status": "error",
            "error": str(e),
            "agent": "analysis_agent",
            "analysis": None
        }
