"""
DecisionOS v2 — Orchestrator
==============================
Role     : Master coordinator — receives question, delegates to agents,
           builds reasoning chain, assembles final report
Input    : Business question (string)
Output   : Complete decision report with reasoning chain and confidence score

Pipeline : Data Agent → Analysis Agent → Risk Agent → Recommendation Agent
           (sequential — each agent receives output of the previous)

Error handling:
  - If any agent fails, the orchestrator reports the failure clearly
  - It does NOT crash — it returns a partial result with error details
  - Low confidence (<0.6) triggers a human review flag automatically
"""

import os
import json
import time
from datetime import datetime
from anthropic import Anthropic

from agents.data_agent           import run_data_agent
from agents.analysis_agent       import run_analysis_agent
from agents.risk_agent           import run_risk_agent
from agents.recommendation_agent import run_recommendation_agent


def run_orchestrator(business_question: str, api_key: str) -> dict:
    """
    Main orchestrator function.
    Runs the full 4-agent pipeline and returns a complete decision report.
    """

    print(f"\n{'='*60}")
    print(f"  DecisionOS v2 — Orchestrator")
    print(f"{'='*60}")
    print(f"  Question : {business_question}")
    print(f"  Started  : {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"{'='*60}\n")

    # ── Initialise Anthropic client ──────────────────────────────────────
    client = Anthropic(api_key=api_key)
    reasoning_chain = []
    start_time = time.time()

    # ════════════════════════════════════════════════════════════════════
    # STEP 1 — DATA AGENT
    # ════════════════════════════════════════════════════════════════════
    print("[Orchestrator] Step 1/4 → Data Agent")
    data_result = run_data_agent(business_question, client)

    reasoning_chain.append({
        "step":    1,
        "agent":   "Data Agent",
        "status":  data_result["status"],
        "summary": (
            f"Retrieved data — quality: {data_result['data'].get('data_quality', 'N/A')}, "
            f"age: {data_result['data'].get('data_age_days', 'N/A')} days"
            if data_result["status"] == "success"
            else f"FAILED: {data_result.get('error', 'unknown error')}"
        )
    })

    if data_result["status"] != "success":
        return _build_error_report(business_question, reasoning_chain,
                                   "Data Agent failed", start_time)

    data = data_result["data"]

    # ════════════════════════════════════════════════════════════════════
    # STEP 2 — ANALYSIS AGENT
    # ════════════════════════════════════════════════════════════════════
    print("\n[Orchestrator] Step 2/4 → Analysis Agent")
    analysis_result = run_analysis_agent(business_question, data, client)

    reasoning_chain.append({
        "step":    2,
        "agent":   "Analysis Agent",
        "status":  analysis_result["status"],
        "summary": (
            f"Trend: {analysis_result['analysis'].get('trend', 'N/A')}, "
            f"Urgency: {analysis_result['analysis'].get('urgency', 'N/A')}, "
            f"Findings: {len(analysis_result['analysis'].get('key_findings', []))}"
            if analysis_result["status"] == "success"
            else f"FAILED: {analysis_result.get('error', 'unknown error')}"
        )
    })

    if analysis_result["status"] != "success":
        return _build_error_report(business_question, reasoning_chain,
                                   "Analysis Agent failed", start_time)

    analysis = analysis_result["analysis"]

    # ════════════════════════════════════════════════════════════════════
    # STEP 3 — RISK AGENT
    # ════════════════════════════════════════════════════════════════════
    print("\n[Orchestrator] Step 3/4 → Risk Agent")
    risk_result = run_risk_agent(business_question, data, analysis, client)

    reasoning_chain.append({
        "step":    3,
        "agent":   "Risk Agent",
        "status":  risk_result["status"],
        "summary": (
            f"Risk level: {risk_result['risk'].get('overall_risk_level', 'N/A')}, "
            f"Score: {risk_result['risk'].get('risk_score', 'N/A')}, "
            f"Risks identified: {len(risk_result['risk'].get('risks', []))}"
            if risk_result["status"] == "success"
            else f"FAILED: {risk_result.get('error', 'unknown error')}"
        )
    })

    # Risk agent failure is non-fatal — continue with empty risk
    if risk_result["status"] != "success":
        print("  [Orchestrator] Risk Agent failed — continuing with default risk assessment")
        risk = {
            "overall_risk_level": "medium",
            "risk_score": 5.0,
            "risks": [],
            "worst_case_scenario": "Unable to assess — risk agent error",
            "model_risks": {}
        }
    else:
        risk = risk_result["risk"]

    # ════════════════════════════════════════════════════════════════════
    # STEP 4 — RECOMMENDATION AGENT
    # ════════════════════════════════════════════════════════════════════
    print("\n[Orchestrator] Step 4/4 → Recommendation Agent")
    rec_result = run_recommendation_agent(
        business_question, data, analysis, risk, client
    )

    reasoning_chain.append({
        "step":    4,
        "agent":   "Recommendation Agent",
        "status":  rec_result["status"],
        "summary": (
            f"Decision: {rec_result['recommendation'].get('decision', 'N/A').upper()}, "
            f"Confidence: {rec_result['recommendation'].get('confidence', 0)*100:.0f}%"
            if rec_result["status"] == "success"
            else f"FAILED: {rec_result.get('error', 'unknown error')}"
        )
    })

    if rec_result["status"] != "success":
        return _build_error_report(business_question, reasoning_chain,
                                   "Recommendation Agent failed", start_time)

    rec = rec_result["recommendation"]

    # ════════════════════════════════════════════════════════════════════
    # ASSEMBLE FINAL REPORT
    # ════════════════════════════════════════════════════════════════════
    elapsed = round(time.time() - start_time, 2)
    confidence = rec.get("confidence", 0)
    needs_review = confidence < 0.6

    report = {
        "status":           "success",
        "question":         business_question,
        "decision":         rec.get("decision", "unknown").upper(),
        "confidence":       confidence,
        "confidence_pct":   f"{confidence*100:.0f}%",
        "primary_reason":   rec.get("primary_reason", ""),
        "key_findings":     rec.get("key_findings", []),
        "risks":            [r.get("risk", "") for r in risk.get("risks", [])],
        "next_steps":       rec.get("next_steps", []),
        "data_gaps":        rec.get("data_gaps", []),
        "expected_impact":  rec.get("expected_impact", ""),
        "data_quality":     data.get("data_quality", "unknown"),
        "data_age_days":    data.get("data_age_days", "unknown"),
        "trend":            analysis.get("trend", "unknown"),
        "urgency":          analysis.get("urgency", "unknown"),
        "risk_level":       risk.get("overall_risk_level", "unknown"),
        "risk_score":       risk.get("risk_score", 0),
        "reasoning_chain":  reasoning_chain,
        "needs_human_review": needs_review,
        "elapsed_seconds":  elapsed,
        "timestamp":        datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    }

    # ════════════════════════════════════════════════════════════════════
    # PRINT FORMATTED REPORT
    # ════════════════════════════════════════════════════════════════════
    _print_report(report)

    return report


def _build_error_report(question, chain, reason, start_time):
    """Return a clean error report when a critical agent fails."""
    return {
        "status":           "error",
        "question":         question,
        "reason":           reason,
        "reasoning_chain":  chain,
        "elapsed_seconds":  round(time.time() - start_time, 2),
        "timestamp":        datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    }


def _print_report(report):
    """Pretty-print the final decision report to the console."""
    bar = "=" * 60

    print(f"\n{bar}")
    print(f"  DECISIONOS v2 — DECISION REPORT")
    print(bar)
    print(f"  Question   : {report['question']}")
    print(f"  Decision   : {report['decision']}")
    print(f"  Confidence : {report['confidence_pct']}  "
          f"(data quality: {report['data_quality']})")
    print(f"  Reason     : {report['primary_reason']}")
    print(f"  Trend      : {report['trend']}  |  "
          f"Urgency: {report['urgency']}  |  "
          f"Risk: {report['risk_level']}")

    print(f"\n  Key Findings:")
    for f in report.get("key_findings", []):
        print(f"    • {f}")

    print(f"\n  Risks Identified:")
    for r in report.get("risks", []):
        print(f"    ! {r}")

    print(f"\n  Recommended Next Steps:")
    for i, s in enumerate(report.get("next_steps", []), 1):
        print(f"    {i}. {s}")

    if report.get("data_gaps"):
        print(f"\n  Data Gaps:")
        for g in report["data_gaps"]:
            print(f"    ? {g}")

    if report.get("expected_impact"):
        print(f"\n  Expected Impact : {report['expected_impact']}")

    if report.get("needs_human_review"):
        print(f"\n  ⚠  LOW CONFIDENCE — recommend human review before acting.")

    print(f"\n  Reasoning Chain:")
    for step in report.get("reasoning_chain", []):
        status_icon = "✓" if step["status"] == "success" else "✗"
        print(f"    [{status_icon}] Step {step['step']} — {step['agent']}: {step['summary']}")

    print(f"\n  Completed in {report['elapsed_seconds']}s")
    print(bar + "\n")
