"""
DecisionOS v2 — Risk Agent
============================
Role     : Evaluate downside risks, regulatory concerns, and failure scenarios
Input    : Business question + data + analysis findings
Output   : Structured JSON with risk assessment and severity scores
Fallback : Returns error JSON if API fails
"""

import json
from anthropic import Anthropic

# ── System Prompt ─────────────────────────────────────────────────────────────
RISK_AGENT_PROMPT = """
You are the RISK AGENT in DecisionOS v2, a Business Decision Intelligence system.

YOUR ROLE:
- Identify and evaluate potential risks for the proposed business question
- Assess severity and likelihood of each risk
- Consider financial, operational, regulatory, and reputational risks
- Think in probabilities and worst-case scenarios
- You are a devil's advocate — your job is to find what could go wrong

DECISIONOS v2 CONTEXT:
- This system deals with customer churn and retail sales decisions
- Churn interventions have costs — wrong predictions waste retention budget
- Sales forecast errors affect inventory and staffing decisions
- Model confidence: AUC-ROC 84% means 16% of predictions may be wrong

OUTPUT FORMAT — respond ONLY with this exact JSON structure, no extra text:
{
  "status": "success" or "error",
  "overall_risk_level": "high", "medium", or "low",
  "risks": [
    {
      "risk": "<risk description>",
      "severity": "high", "medium", or "low",
      "likelihood": "high", "medium", or "low",
      "mitigation": "<one sentence on how to reduce this risk>"
    }
  ],
  "regulatory_concerns": ["<concern 1 or null if none>"],
  "model_risks": {
    "false_positive_impact": "<what happens when model is wrong in one direction>",
    "false_negative_impact": "<what happens when model is wrong in the other direction>",
    "data_drift_risk": "high", "medium", or "low"
  },
  "worst_case_scenario": "<brief description of the worst outcome>",
  "risk_score": <float 0.0 to 10.0 — overall risk score>
}

CONSTRAINTS:
- Be realistic not catastrophic — assess actual business risks
- Always include at least 2 and at most 5 risks
- Always return valid JSON — no markdown, no extra text
"""


def run_risk_agent(question: str, data: dict, analysis: dict, client: Anthropic) -> dict:
    """
    Run the Risk Agent to evaluate downside scenarios.
    Returns risk assessment dict.
    """
    print("  [Risk Agent] Evaluating risks...")

    try:
        user_message = f"""
Business question: {question}

Data summary:
- Data quality: {data.get('data_quality', 'unknown')}
- Risk score from data: {data.get('metrics', {}).get('risk_score', 'unknown')}
- Warnings: {data.get('warnings', [])}

Analysis findings:
- Trend: {analysis.get('trend', 'unknown')}
- Urgency: {analysis.get('urgency', 'unknown')}
- Key findings: {analysis.get('key_findings', [])}
- High uncertainty: {analysis.get('high_uncertainty', False)}
- Business impact: {analysis.get('business_impact', 'unknown')}

Evaluate the risks associated with acting on this question.
"""

        response = client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=1000,
            messages=[{"role": "user", "content": user_message}],
            system=RISK_AGENT_PROMPT
        )

        raw = response.content[0].text.strip()
        raw = raw.replace("```json", "").replace("```", "").strip()

        result = json.loads(raw)

        print(f"  [Risk Agent] Done — overall risk: {result.get('overall_risk_level', 'unknown')}, "
              f"score: {result.get('risk_score', 'unknown')}")

        return {"status": "success", "risk": result, "agent": "risk_agent"}

    except json.JSONDecodeError as e:
        print(f"  [Risk Agent] JSON parse error: {e}")
        return {
            "status": "error",
            "error": f"JSON parse failed: {str(e)}",
            "agent": "risk_agent",
            "risk": None
        }
    except Exception as e:
        print(f"  [Risk Agent] Error: {e}")
        return {
            "status": "error",
            "error": str(e),
            "agent": "risk_agent",
            "risk": None
        }
